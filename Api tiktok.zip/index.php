<?php
header('content-type: application/json');
$link = $_SERVER['SERVER_NAME'];
$data = [
    "server" => "Online",
    "tiktok" => true,
    "sample_tiktok" => "https://".$link.'/tiktok?url=https://www.tiktok.com/@koko.lee84/video/7150217934588218651?is_from_webapp=1&sender_device=pc',
];
echo json_encode($data);