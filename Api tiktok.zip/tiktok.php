<?php
$tiktokURL = $_GET['url'];
// index.php
require __DIR__ . '/vendor/autoload.php';
header('content-type: application/json');
use GuzzleHttp\Client;
$client = new Client([
    // default timeout 5 detik
    'timeout'  => 5,
    'verify' => false
]);
$params = [
    'headers' => [
        // 'User-Agent' => 'testing/1.0',
        'Accept'     => 'application/json',
    ],
    'form_params' => [
        'query' => $tiktokURL
    ]
];
$response = $client->request('POST', 'https://lovetik.com/api/ajax/search', $params);
$body = $response->getBody();
$Array = json_decode($body,true);
$arrayD = [
    "status" => "ok",
    "original" => $tiktokURL,
    "desc" => $Array['desc'],
    "author" => $Array['author'],
    "cover" => $Array['cover'],
    "links" => [
        "mp3" => $Array['links'][4]['a'],
        "video" => $Array['links'][3]['a']
    ]
];
echo json_encode($arrayD);