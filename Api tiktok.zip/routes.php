<?php
require_once("router.php");

get('/tiktok','/tiktok.php');
get('/','/index.php');
